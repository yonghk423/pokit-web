import type { Metadata } from "next";
import { PortableText } from "next-sanity";
import Image from "next/image";
import Link from "next/link";
import { notFound, permanentRedirect } from "next/navigation";

import { AddToPokitCta } from "@/components/add-to-pokit-cta";
import { ArticleDisplayTitle } from "@/components/article-display-title";
import { JsonLd } from "@/components/json-ld";
import { RelatedArticles } from "@/components/related-articles";
import { siteName } from "@/config/site";
import { isLocale, locales, type Locale } from "@/i18n/config";
import { createTranslator } from "@/i18n/create-translator";
import { getArticleMessages } from "@/i18n/get-article-messages";
import { getAppInstallMessages } from "@/i18n/get-app-install-messages";
import { getCommonMessages } from "@/i18n/get-common-messages";
import { createCategoryLabels } from "@/i18n/category-labels";
import { articleSeo } from "@/lib/article-seo";
import { isValidArticleSlug } from "@/lib/article-path";
import { cn, monoContainer } from "@/lib/cn";
import { formatPublishedLabel } from "@/lib/format-published";
import { articleJsonLd, breadcrumbJsonLd } from "@/lib/json-ld";
import { localeAlternates, localeOpenGraph, withLocale } from "@/lib/locale-path";
import { shouldShowPokitCta, toPokitRoutineArticle } from "@/lib/pokit-bridge";
import { client } from "@/sanity/client";
import { isSanityConfigured } from "@/sanity/env";
import { coverImageUrl, imageBlurProps } from "@/sanity/image";
import { getArticleBySlug } from "@/sanity/lib/article";
import { getRelatedArticles } from "@/sanity/lib/articles";
import { sanityFetchOptions } from "@/sanity/lib/cache";
import { ARTICLE_SLUGS_QUERY } from "@/sanity/lib/queries";

export const revalidate = false;
export const dynamicParams = true;

type Props = {
  params: Promise<{ locale: string; slug: string }>;
};

export async function generateStaticParams() {
  if (!isSanityConfigured() || !client) {
    return [];
  }

  const slugs = await client.fetch<{ slug: string }[]>(
    ARTICLE_SLUGS_QUERY,
    {},
    sanityFetchOptions,
  );

  return locales.flatMap((locale) =>
    slugs.map(({ slug }) => ({ locale, slug })),
  );
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale: rawLocale, slug: rawSlug } = await params;

  if (!isLocale(rawLocale) || !isSanityConfigured() || !client) {
    return { title: "Article" };
  }

  const slug = decodeURIComponent(rawSlug);
  if (!isValidArticleSlug(slug)) {
    return { title: "Article" };
  }

  const article = await getArticleBySlug(slug, rawLocale);
  if (!article) {
    return { title: "Article not found" };
  }

  const coverImage = coverImageUrl(article.coverImage, 1200, 630) ?? undefined;
  const { availableLocales, contentLocale, indexable, title, description } = articleSeo(article, rawLocale);
  const canonicalPath = article.appStory ? `/app/yourday-story/${slug}` : `/articles/${slug}`;
  const alternates = localeAlternates(rawLocale, canonicalPath, {
    availableLocales,
  });

  return {
    title,
    description,
    alternates,
    robots: !indexable ? { index: false, follow: true } : undefined,
    openGraph: {
      title,
      description,
      type: "article",
      siteName: siteName(),
      url: alternates.canonical,
      publishedTime: article.publishedAt,
      modifiedTime: article._updatedAt,
      locale: localeOpenGraph(contentLocale),
      images: coverImage
        ? [
          {
            url: coverImage,
            width: 1200,
            height: 630,
            alt: article.imageAlt,
          },
        ]
        : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: coverImage ? [coverImage] : undefined,
    },
  };
}

export default async function ArticlePage({ params }: Props) {
  const { locale: rawLocale, slug: rawSlug } = await params;

  if (!isLocale(rawLocale)) {
    notFound();
  }

  if (!isSanityConfigured() || !client) {
    notFound();
  }

  const locale: Locale = rawLocale;
  const slug = decodeURIComponent(rawSlug);
  if (!isValidArticleSlug(slug)) {
    notFound();
  }

  const [commonMessages, articleMessages, installMessages] = await Promise.all([
    getCommonMessages(locale),
    getArticleMessages(locale),
    getAppInstallMessages(locale),
  ]);
  const categoryLabels = createCategoryLabels(createTranslator(commonMessages));
  const commonT = createTranslator(commonMessages);
  const t = createTranslator(articleMessages);
  const article = await getArticleBySlug(slug, locale);

  if (!article) {
    notFound();
  }
  if (article.appStory) {
    permanentRedirect(withLocale(locale, `/app/yourday-story/${slug}`));
  }

  const related = await getRelatedArticles(
    slug,
    article.category,
    locale,
    categoryLabels,
  );
  const showKoreanOnlyBanner =
    (locale === "en" && article.hasEnglishTranslation === false) ||
    (locale === "ja" && article.hasJapaneseTranslation === false) ||
    (locale === "zh-TW" && article.hasTraditionalChineseTranslation === false);

  const coverUrl = coverImageUrl(article.coverImage, 1200, 675);
  const jsonLdImage = coverImageUrl(article.coverImage, 1200, 630) ?? undefined;
  const { description, contentLocale: jsonLdLocale } = articleSeo(article, locale);

  return (
    <>
      <JsonLd
        data={articleJsonLd({
          locale: jsonLdLocale,
          slug,
          title: article.title,
          description,
          publishedAt: article.publishedAt,
          modifiedAt: article._updatedAt,
          imageUrl: jsonLdImage,
        })}
      />
      <JsonLd
        data={breadcrumbJsonLd(
          [
            { name: siteName(), path: "/" },
            { name: commonT("모든 이야기"), path: "/articles" },
            { name: article.title, path: `/articles/${slug}` },
          ],
          jsonLdLocale,
        )}
      />
      <main className={cn(monoContainer, "py-12 pb-20")}>
        <Link
          href={withLocale(locale, "/")}
          className="mb-10 inline-block bg-ink px-4 py-2 label-caps text-white hover:bg-indigo transition-colors rounded-full"
        >
          {t("← Back to POKIT")}
        </Link>

        {showKoreanOnlyBanner && (
          <p
            className="mb-8 max-w-[42rem] border border-ink/12 bg-[#f8eee8] px-5 py-4 font-sans text-[0.88rem] leading-[1.6] text-ink"
            role="note"
          >
            {t("이 글은 아직 영문 번역이 준비되지 않았습니다. 한국어 원문을 표시하고 있습니다.")}
          </p>
        )}

        <header className="mb-10">
          {article.kicker && (
            <p className="m-0 mb-4 max-w-[42rem] label-caps text-green">
              {article.kicker}
            </p>
          )}
          <ArticleDisplayTitle
            title={article.title}
            locale={locale}
            category={article.category}
            description={article.description}
            as="h1"
            className="m-0 font-sans text-[clamp(1.75rem,3.25vw,2.65rem)] font-extrabold leading-[1.1] tracking-[-0.03em]"
          />
          {article.description && (
            <p className="mt-5 mb-0 max-w-[42rem] font-sans text-[1.05rem] leading-[1.65] text-muted">
              {article.description}
            </p>
          )}
          {article.publishedAt && (
            <p className="mt-5 mb-0 max-w-[42rem] label-caps text-muted">
              <time dateTime={article.publishedAt}>
                {formatPublishedLabel(article.publishedAt, locale)}
              </time>
            </p>
          )}
        </header>
        {coverUrl && (
          <figure data-article-cover className="relative mb-12 overflow-hidden rounded-[1.25rem] border border-ink/12 bg-[#f3f0e8]" style={{ aspectRatio: "16 / 9" }}>
            <Image
              src={coverUrl}
              alt={article.imageAlt}
              fill
              preload
              className="object-cover"
              sizes="(min-width: 1334px) calc(100vw - 48px), 96.4vw"
              {...imageBlurProps(article.coverImageLqip)}
            />
          </figure>
        )}
        {article.body && (
          <div className="prose max-w-[42rem] font-sans text-ink">
            <PortableText value={article.body} />
          </div>
        )}
        {shouldShowPokitCta(article) && (
          <AddToPokitCta
            article={toPokitRoutineArticle(article)}
            locale={locale}
            messages={installMessages}
          />
        )}
        {related && (
          <RelatedArticles
            related={related}
            locale={locale}
            categoryLabels={categoryLabels}
            heading={t("{{label}} 이야기", {
              label: locale === "en" ? related.label.toLowerCase() : related.label,
            })}
            viewMoreLabel={t("더보기 →")}
          />
        )}

      </main>
    </>
  );
}
