"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState, type MouseEvent } from "react";

import { useOptionalArticlePreview } from "@/components/article-preview-context";
import { DisplayHeading } from "@/components/display-heading";
import { HomeHeroDownload } from "@/components/home-hero-download";
import { siteName, appStoreUrl } from "@/config/site";
import { articlePath } from "@/lib/article-path";
import { cn, monoContainer } from "@/lib/cn";
import { splitDisplayTitle } from "@/lib/display-title";
import type { Locale } from "@/i18n/config";
import { localeToIntl } from "@/i18n/config";
import type { CategoryLabels } from "@/i18n/category-labels";
import { createTranslator } from "@/i18n/create-translator";
import type { HomeVideoMessages } from "@/i18n/get-home-video-messages";
import type { AppDownloadMessages } from "@/i18n/get-app-download-messages";
import { isSanityConfigured } from "@/sanity/env";
import { coverImageUrl, imageBlurProps } from "@/sanity/image";
import type { ArticleCardData } from "@/sanity/types";

type Props = {
  locale: Locale;
  line1: string;
  accent: string;
  rest: string;
  feedTitle: string;
  feedPrevLabel: string;
  feedNextLabel: string;
  videoMessages: HomeVideoMessages;
  heroArticles: ArticleCardData[];
  feedArticles: ArticleCardData[];
  categoryLabels: CategoryLabels;
  downloadMessages: AppDownloadMessages;
};

const feedNavBtnClass =
  "inline-flex size-8 shrink-0 cursor-pointer items-center justify-center rounded-md border-0 bg-ink/[0.05] p-0 font-sans text-[0.8rem] font-medium leading-none text-ink/55 transition-colors hover:bg-ink hover:text-paper disabled:cursor-not-allowed disabled:bg-transparent disabled:text-ink/20";

function formatFeedDate(iso: string | null | undefined, locale: Locale) {
  if (!iso) return null;
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return null;
  return new Intl.DateTimeFormat(localeToIntl(locale), {
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

function openPreviewFromElement(
  preview: ReturnType<typeof useOptionalArticlePreview>,
  article: ArticleCardData,
  event: MouseEvent<HTMLAnchorElement>,
  imageUrl: string | null,
) {
  if (!preview || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  const rect = event.currentTarget.getBoundingClientRect();
  preview.open({
    article,
    origin: {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height,
      imageUrl,
      blurDataURL: article.coverImageLqip ?? null,
    },
  });
}

/** Oimachi `.posts_item-link.is-home` equivalent */
function FeedCard({
  article,
  locale,
  categoryLabels,
}: {
  article: ArticleCardData;
  locale: Locale;
  categoryLabels: CategoryLabels;
}) {
  const preview = useOptionalArticlePreview();
  const headline = splitDisplayTitle(article.title).headline;
  const imageUrl = isSanityConfigured()
    ? coverImageUrl(article.coverImage, 960, 640)
    : null;
  const category =
    categoryLabels[article.category as keyof typeof categoryLabels] ??
    article.category;
  const dateLabel = formatFeedDate(article.publishedAt, locale);

  return (
    <a
      href={articlePath(locale, article.slug)}
      className="group/feed relative block w-full cursor-pointer overflow-visible border-0 bg-transparent p-0 text-left"
      onClick={(event) =>
        openPreviewFromElement(preview, article, event, imageUrl)
      }
    >
      <div className="relative overflow-visible pr-7">
        <p className="m-0 overflow-visible font-sans text-[0.72rem] leading-normal text-muted">
          {category}
          {dateLabel ? ` · ${dateLabel}` : null}
        </p>
        <p className="m-0 mt-2.5 truncate font-sans text-[0.95rem] font-bold leading-snug tracking-[-0.02em] text-ink">
          {headline}
        </p>
        {article.description ? (
          <p className="m-0 mt-1.5 line-clamp-2 font-sans text-[0.75rem] leading-[1.45] text-muted">
            {article.description}
          </p>
        ) : null}
        <span
          className="absolute top-0 right-0 flex size-5 items-center justify-center font-sans text-[1.1rem] font-light leading-none text-ink/40 transition-colors group-hover/feed:text-ink"
          aria-hidden
        >
          +
        </span>
      </div>

      {imageUrl ? (
        <div className="relative mt-3 aspect-[16/10] overflow-hidden rounded-[0.3rem] bg-[#ebe7df]">
          <Image
            src={imageUrl}
            alt={article.imageAlt || headline}
            fill
            sizes="(max-width: 900px) 78vw, 22vw"
            className="object-cover transition-transform duration-500 group-hover/feed:scale-[1.03]"
            {...imageBlurProps(article.coverImageLqip)}
          />
        </div>
      ) : null}
    </a>
  );
}

export function HomeHero({
  locale,
  line1,
  accent,
  rest,
  feedTitle,
  feedPrevLabel,
  feedNextLabel,
  videoMessages,
  heroArticles,
  feedArticles,
  categoryLabels,
  downloadMessages,
}: Props) {
  const t = createTranslator(videoMessages);
  const downloadT = createTranslator(downloadMessages);
  const preview = useOptionalArticlePreview();
  const feedScrollRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);
  const [videoPlaying, setVideoPlaying] = useState(true);
  const hero = heroArticles.find((article) => article.coverImage) ?? heroArticles[0];
  const heroUrl =
    hero && isSanityConfigured()
      ? coverImageUrl(hero.coverImage, 2000, 1125)
      : null;
  const heroHeadline = hero
    ? splitDisplayTitle(hero.title).headline
    : null;
  const feed = feedArticles.slice(0, 6);

  const updateFeedControls = useCallback(() => {
    const el = feedScrollRef.current;
    if (!el) return;
    setCanPrev(el.scrollLeft > 4);
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  }, []);

  useEffect(() => {
    const el = feedScrollRef.current;
    if (!el) return;
    updateFeedControls();
    el.addEventListener("scroll", updateFeedControls, { passive: true });
    window.addEventListener("resize", updateFeedControls);
    return () => {
      el.removeEventListener("scroll", updateFeedControls);
      window.removeEventListener("resize", updateFeedControls);
    };
  }, [feed.length, updateFeedControls]);

  const scrollFeedByCard = useCallback((direction: "prev" | "next") => {
    const el = feedScrollRef.current;
    if (!el) return;
    const card = el.querySelector<HTMLElement>("[data-feed-card]");
    const step = card ? card.offsetWidth + 12 : el.clientWidth * 0.8;
    el.scrollBy({
      left: direction === "next" ? step : -step,
      behavior: "smooth",
    });
  }, []);

  const toggleVideo = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      void video.play();
      return;
    }
    video.pause();
  }, []);

  return (
    <section className="relative pt-8 max-nav:pt-6">
      <div className={monoContainer}>
        {/* hero title + compact download */}
        <div className="home-hero-rise flex items-end justify-between gap-6 max-nav:flex-col max-nav:items-stretch max-nav:gap-0">
          <DisplayHeading
            line1={line1}
            accent={accent}
            rest={rest}
            as="h1"
            className="min-w-0 max-w-[52rem] flex-1 text-[clamp(2rem,5vw,3.75rem)]"
          />
          <div className="flex shrink-0 items-end gap-4 max-nav:w-full max-nav:flex-col max-nav:items-stretch">
            <div className="group relative mb-0.5 max-nav:mb-0">
              <a
                href={appStoreUrl(locale)}
                aria-label={downloadT("App Store에서 다운로드")}
                className="block cursor-pointer"
              >
                <video
                  ref={videoRef}
                  className="pointer-events-none h-auto w-[16rem] max-w-[min(22rem,34vw)] rounded-[0.7rem] object-cover max-nav:h-auto max-nav:w-full max-nav:max-w-none"
                  src="/your-day-header-us.mp4"
                  poster="/your-day-header-us.webp"
                  preload="metadata"
                  width={1920}
                  height={824}
                  autoPlay
                  muted
                  loop
                  playsInline
                  aria-label={t("POKIT 앱 소개 영상")}
                  onPlay={() => setVideoPlaying(true)}
                  onPause={() => setVideoPlaying(false)}
                />
              </a>
              <button
                type="button"
                onClick={toggleVideo}
                aria-label={videoPlaying ? t("영상 정지") : t("영상 재생")}
                className="pointer-events-none absolute bottom-2 left-2 z-10 inline-flex size-8 cursor-pointer items-center justify-center rounded-full border-0 bg-ink/75 p-0 text-white opacity-0 transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-visible:pointer-events-auto focus-visible:opacity-100 max-nav:pointer-events-auto max-nav:opacity-100"
              >
                {videoPlaying ? (
                  <span className="flex gap-[3px]" aria-hidden>
                    <span className="block h-3 w-[3px] rounded-sm bg-white" />
                    <span className="block h-3 w-[3px] rounded-sm bg-white" />
                  </span>
                ) : (
                  <span
                    aria-hidden
                    className="ml-0.5 block h-0 w-0 border-y-[6px] border-l-[9px] border-y-transparent border-l-white"
                  />
                )}
              </button>
            </div>
            <HomeHeroDownload locale={locale} messages={downloadMessages} />
          </div>
        </div>

        {/* Oimachi `.hero_bottom`: height calc(100svh - 18rem), flex row, gap 0.4rem */}
        <div className="mt-3 flex h-[calc(100svh-18rem)] gap-[0.4rem] max-nav:mt-4 max-nav:h-auto max-nav:flex-col max-nav:gap-8">
          {/* `.hero_graphic` */}
          {hero ? (
            <a
              href={articlePath(locale, hero.slug)}
              className="home-hero-rise home-hero-rise-delay group/hero relative h-full min-w-0 flex-1 cursor-pointer overflow-hidden rounded-[0.3rem] border-0 bg-[#ebe7df] p-0 text-left max-nav:aspect-square max-nav:h-auto max-nav:w-full"
              aria-label={heroHeadline ?? feedTitle}
              onClick={(event) =>
                openPreviewFromElement(preview, hero, event, heroUrl)
              }
            >
              {heroUrl ? (
                <Image
                  src={heroUrl}
                  alt={hero.imageAlt || heroHeadline || ""}
                  fill
                  priority
                  sizes="(max-width: 900px) 100vw, 72vw"
                  className="object-cover transition-transform duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover/hero:scale-[1.015]"
                  {...imageBlurProps(hero.coverImageLqip)}
                />
              ) : (
                <span className="grid h-full place-items-center font-sans text-sm font-extrabold tracking-[0.14em] text-indigo uppercase">
                  {siteName()}
                </span>
              )}
            </a>
          ) : (
            <div className="h-full min-w-0 flex-1 rounded-[0.3rem] bg-[#ebe7df] max-nav:aspect-square max-nav:h-auto" />
          )}

          {/* `.hero_feed` — vertical scroll on desktop, horizontal snap on mobile */}
          <aside
            className={cn(
              "relative flex h-full w-[21rem] shrink-0 flex-col overflow-visible",
              "max-nav:h-auto max-nav:w-full",
            )}
            aria-label={feedTitle}
          >
            <div className="relative min-h-0 flex-1 overflow-visible">
              <div
                ref={feedScrollRef}
                className={cn(
                  "scrollbar-hide absolute inset-0 overflow-y-auto overflow-x-visible",
                  "max-nav:relative max-nav:inset-auto max-nav:flex max-nav:snap-x max-nav:snap-mandatory max-nav:overflow-x-auto max-nav:overflow-y-hidden max-nav:scroll-smooth",
                )}
              >
                <div
                  className={cn(
                    "flex flex-col gap-5 pt-1 pb-8",
                    "max-nav:w-max max-nav:flex-row max-nav:gap-3 max-nav:pt-0 max-nav:pb-1",
                  )}
                >
                  {feed.map((article) => (
                    <div
                      key={article.slug}
                      data-feed-card
                      className="min-w-0 max-nav:w-[min(17.5rem,78vw)] max-nav:shrink-0 max-nav:snap-center"
                    >
                      <FeedCard
                        article={article}
                        locale={locale}
                        categoryLabels={categoryLabels}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div
                className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-10 bg-gradient-to-t from-[var(--color-paper)] to-transparent max-nav:hidden"
                aria-hidden
              />
            </div>

            {feed.length > 1 ? (
              <div className="mt-4 flex items-center gap-2 nav:hidden">
                <button
                  type="button"
                  className={feedNavBtnClass}
                  aria-label={feedPrevLabel}
                  disabled={!canPrev}
                  onClick={() => scrollFeedByCard("prev")}
                >
                  ←
                </button>
                <button
                  type="button"
                  className={feedNavBtnClass}
                  aria-label={feedNextLabel}
                  disabled={!canNext}
                  onClick={() => scrollFeedByCard("next")}
                >
                  →
                </button>
              </div>
            ) : null}
          </aside>
        </div>
      </div>
    </section>
  );
}
