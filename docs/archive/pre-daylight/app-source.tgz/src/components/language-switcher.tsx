"use client";

import { usePathname } from "next/navigation";

import { locales, type Locale } from "@/i18n/config";
import { switchLocalePath } from "@/lib/locale-path";
import { cn } from "@/lib/cn";

export type LanguageLabels = { label: string } & Record<Locale, string>;

const compactLocaleLabels: Record<Locale, string> = {
  ko: "한국어",
  en: "EN",
  ja: "日本語",
  "zh-TW": "繁中",
};

type Props = {
  locale: Locale;
  labels: LanguageLabels;
  className?: string;
};

export function LanguageSwitcher({ locale, labels, className }: Props) {
  const pathname = usePathname();

  return (
    <div
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-paper px-2.5 py-1 font-sans text-[0.72rem] font-semibold tracking-[0.06em] uppercase ring-1 ring-ink/8",
        className,
      )}
      aria-label={labels.label}
    >
      {locales.map((value, index) => (
        <span key={value} className="inline-flex items-center gap-1">
          {index > 0 && (
            <span className="text-muted" aria-hidden="true">
              /
            </span>
          )}
          {/* Reload across locales so preserved modal routes cannot restore the previous language. */}
          <a
            href={switchLocalePath(pathname, value)}
            aria-label={labels[value]}
            className={cn(
              "px-1 py-0.5",
              locale === value
                ? "rounded-full bg-white px-1.5 text-ink"
                : "text-muted hover:text-ink",
            )}
            aria-current={locale === value ? "true" : undefined}
          >
            <span className="min-[761px]:hidden">{compactLocaleLabels[value]}</span>
            <span className="hidden min-[761px]:inline">{labels[value]}</span>
          </a>
        </span>
      ))}
    </div>
  );
}
