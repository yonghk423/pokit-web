"use client";

import type { AppInstallMessages } from "@/i18n/get-app-install-messages";

import { PortableText, type PortableTextBlock } from "next-sanity";
import {
  useEffect,
  useId,
  useRef,
  useState,
  type CSSProperties,
} from "react";

import { AddToPokitCta } from "@/components/add-to-pokit-cta";
import { ArticleDisplayTitle } from "@/components/article-display-title";
import {
  useArticlePreview,
  type ArticlePreviewOrigin,
} from "@/components/article-preview-context";
import { ArticlePreviewBodySkeleton } from "@/components/article-preview-skeleton";
import { PreviewCoverImage } from "@/components/preview-cover-image";
import { cn } from "@/lib/cn";
import { formatPublishedLabel } from "@/lib/format-published";
import {
  DEFAULT_DURATION_MINUTES,
  toPokitRoutineArticle,
} from "@/lib/pokit-bridge";
import type { CategoryLabels } from "@/i18n/category-labels";

type PreviewArticle = {
  slug: string;
  title: string;
  titleKo: string | null;
  description: string | null;
  kicker: string | null;
  category: string;
  categoryKey: string | null;
  durationMinutes: number | null;
  imageAlt: string;
  publishedAt: string | null;
  body: PortableTextBlock[] | null;
  coverUrl: string | null;
  coverImageLqip: string | null;
};

type Props = {
  categoryLabels: CategoryLabels;
  closeLabel: string;
  installMessages: AppInstallMessages;
  preview?: Pick<ReturnType<typeof useArticlePreview>, "locale" | "active" | "close">;
};

function originStyle(origin: ArticlePreviewOrigin): CSSProperties {
  return {
    position: "fixed",
    top: origin.top,
    left: origin.left,
    width: origin.width,
    height: origin.height,
    borderRadius: "1.15rem",
  };
}

function rectStyle(rect: DOMRect): CSSProperties {
  return {
    position: "fixed",
    top: rect.top,
    left: rect.left,
    width: rect.width,
    height: rect.height,
    borderRadius: "1.15rem",
  };
}

export function ArticlePreviewModal({
  categoryLabels,
  closeLabel,
  installMessages,
  preview,
}: Props) {
  const context = useArticlePreview();
  const { locale, active, close } = preview ?? context;
  const titleId = useId();
  const mediaRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const flyRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"from" | "to" | "ready">("from");
  const [target, setTarget] = useState<CSSProperties | null>(null);
  const [detail, setDetail] = useState<PreviewArticle | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const articleActive = active?.kind === "article" ? active : null;

  useEffect(() => {
    if (!articleActive) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    setPhase("from");
    setTarget(null);
    setLoading(true);
    setError(false);
    setDetail(null);

    let cancelled = false;
    let raf1 = 0;
    let raf2 = 0;
    let raf3 = 0;
    let settleTimer = 0;
    let retryTimer = 0;

    const readTarget = () => {
      const el = mediaRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      if (rect.width < 8 || rect.height < 8) return null;
      return rectStyle(rect);
    };

    const startFlight = () => {
      if (cancelled) return;
      const next = readTarget();
      if (!next) {
        retryTimer = window.setTimeout(startFlight, 32);
        return;
      }

      setTarget(next);

      // Force a paint at the origin before switching to the target.
      raf2 = requestAnimationFrame(() => {
        if (cancelled) return;
        void flyRef.current?.offsetWidth;
        raf3 = requestAnimationFrame(() => {
          if (cancelled) return;
          setPhase("to");
          settleTimer = window.setTimeout(() => {
            if (!cancelled) setPhase("ready");
          }, 520);
        });
      });
    };

    raf1 = requestAnimationFrame(startFlight);

    const controller = new AbortController();
    fetch(
      `/api/articles/${encodeURIComponent(articleActive.article.slug)}?locale=${locale}`,
      { signal: controller.signal },
    )
      .then(async (res) => {
        if (!res.ok) throw new Error("failed");
        return res.json() as Promise<PreviewArticle>;
      })
      .then((data) => {
        if (cancelled) return;
        setDetail(data);
        setLoading(false);
      })
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "AbortError") return;
        if (cancelled) return;
        setError(true);
        setLoading(false);
      });

    function onResize() {
      const next = readTarget();
      if (next) setTarget(next);
    }
    window.addEventListener("resize", onResize);

    return () => {
      cancelled = true;
      document.body.style.overflow = previousOverflow;
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      cancelAnimationFrame(raf3);
      window.clearTimeout(settleTimer);
      window.clearTimeout(retryTimer);
      controller.abort();
      window.removeEventListener("resize", onResize);
    };
  }, [articleActive, locale]);

  useEffect(() => {
    if (!articleActive) return;
    panelRef.current?.focus();
  }, [articleActive]);

  if (!articleActive) return null;

  const imageUrl = articleActive.origin.imageUrl;
  const blurDataURL =
    articleActive.origin.blurDataURL ?? detail?.coverImageLqip ?? null;
  const category =
    categoryLabels[articleActive.article.category as keyof typeof categoryLabels] ??
    articleActive.article.category;
  const hasFlight = Boolean(imageUrl) && phase !== "ready";
  const contentReady = phase === "ready";
  const flyStyle =
    phase === "from" || !target
      ? originStyle(articleActive.origin)
      : target;
  // Keep the already-warm list/card URL so detail fetch does not remount the image.
  const panelSrc = imageUrl ?? detail?.coverUrl;

  return (
    <div className="fixed inset-0 z-[80]" role="presentation">
      <button
        type="button"
        className="absolute inset-0 border-0 bg-ink/45 backdrop-blur-[2px]"
        aria-label={closeLabel}
        onClick={close}
      />

      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={cn(
          "absolute inset-x-1.5 top-1.5 bottom-[max(1.25rem,env(safe-area-inset-bottom))] overflow-hidden rounded-[1.15rem] bg-paper shadow-[0_24px_80px_rgba(24,26,46,0.28)] outline-none",
          "nav:inset-2.5 nav:rounded-[1.35rem]",
          "flex flex-col",
        )}
        data-preview-modal-panel
      >
        <div className="flex shrink-0 items-center justify-between gap-3 px-5 py-2.5 max-nav:px-4">
          <button
            type="button"
            onClick={close}
            className="inline-flex items-center gap-1.5 border-0 bg-transparent p-0 font-sans text-[0.82rem] font-medium tracking-[-0.01em] text-muted transition-colors hover:text-ink"
          >
            <span aria-hidden className="text-[0.95em]">
              ←
            </span>
            {closeLabel}
          </button>
          <button
            type="button"
            onClick={close}
            className="inline-flex size-8 items-center justify-center border-0 bg-transparent p-0 font-sans text-[1.35rem] font-light leading-none text-muted transition-colors hover:text-ink"
            aria-label={closeLabel}
          >
            ×
          </button>
        </div>

        <div className="scrollbar-hide grid min-h-0 flex-1 grid-cols-1 gap-5 overflow-y-auto px-4 pb-[max(2.5rem,env(safe-area-inset-bottom))] pt-1 max-nav:gap-7 nav:grid-cols-[minmax(16rem,0.85fr)_minmax(0,1.25fr)] nav:gap-7 nav:overflow-hidden nav:px-5 nav:pb-5">
          <div className="min-h-0 shrink-0 max-nav:mx-auto max-nav:w-full max-nav:max-w-[22rem]">
            <div
              ref={mediaRef}
              data-preview-cover
              className="relative isolate z-0 overflow-hidden rounded-[1.15rem] bg-[#ebe7df] max-nav:aspect-4/5 max-nav:h-auto max-nav:max-h-[min(34svh,18rem)] max-nav:min-h-0 nav:h-full nav:min-h-72"
            >
              {panelSrc ? (
                <PreviewCoverImage
                  src={panelSrc}
                  alt={
                    detail?.imageAlt ||
                    articleActive.article.imageAlt ||
                    detail?.title ||
                    articleActive.article.title
                  }
                  blurDataURL={blurDataURL}
                  sizes="(max-width: 900px) 90vw, 42vw"
                  priority
                  hidden={hasFlight}
                />
              ) : null}
            </div>
          </div>

          <div
            className={cn(
              "flex min-h-0 min-w-0 flex-col transition-[opacity,transform] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
              contentReady
                ? "translate-x-0 opacity-100"
                : "translate-x-3 opacity-0",
            )}
          >
            {error ? (
              <p className="m-0 font-sans text-[0.9rem] text-muted">
                Failed to load.
              </p>
            ) : null}

            {!error ? (
              <>
                <div className="relative z-[1] shrink-0 border-b border-ink/8 pb-4 max-nav:pt-1">
                  <p className="m-0 font-sans text-[0.72rem] font-semibold leading-snug tracking-[0.06em] text-muted">
                    {category}
                  </p>
                  {(detail?.kicker ?? articleActive.article.kicker) ? (
                    <p className="m-0 mt-3 label-caps text-green">
                      {detail?.kicker ?? articleActive.article.kicker}
                    </p>
                  ) : null}
                  <div id={titleId}>
                    <ArticleDisplayTitle
                      title={detail?.title ?? articleActive.article.title}
                      locale={locale}
                      category={detail?.category ?? articleActive.article.category}
                      description={
                        detail?.description ??
                        articleActive.article.description ??
                        undefined
                      }
                      as="h2"
                      className="m-0 mt-2.5 font-sans text-[clamp(1.45rem,2.5vw,2.15rem)] font-extrabold leading-[1.12] tracking-[-0.03em]"
                    />
                  </div>
                  {(detail?.description ?? articleActive.article.description) ? (
                    <p className="mt-3 mb-0 max-w-[40rem] font-sans text-[0.95rem] leading-[1.6] text-muted">
                      {detail?.description ?? articleActive.article.description}
                    </p>
                  ) : null}
                  {(detail?.publishedAt ?? articleActive.article.publishedAt) ? (
                    <p className="mt-2.5 mb-0 label-caps text-muted">
                      <time
                        dateTime={
                          detail?.publishedAt ??
                          articleActive.article.publishedAt
                        }
                      >
                        {formatPublishedLabel(
                          (detail?.publishedAt ??
                            articleActive.article.publishedAt) as string,
                          locale,
                        )}
                      </time>
                    </p>
                  ) : null}
                </div>

                <div className="scrollbar-hide min-h-0 flex-1 overflow-y-auto overscroll-contain pt-4 max-nav:overflow-visible nav:pt-5">
                  {detail?.body ? (
                    <div className="prose max-w-[44rem] pb-3 font-sans text-ink prose-p:text-[0.96rem] prose-p:leading-[1.75]">
                      <PortableText value={detail.body} />
                    </div>
                  ) : loading ? (
                    <ArticlePreviewBodySkeleton />
                  ) : null}

                  {detail ? (
                    <AddToPokitCta
                      article={toPokitRoutineArticle({
                        slug: detail.slug,
                        title: detail.title,
                        titleKo: detail.titleKo ?? detail.title,
                        description: detail.description ?? undefined,
                        category: detail.category,
                        categoryKey: detail.categoryKey ?? undefined,
                        durationMinutes:
                          detail.durationMinutes && detail.durationMinutes > 0
                            ? detail.durationMinutes
                            : DEFAULT_DURATION_MINUTES,
                        publishedAt: detail.publishedAt ?? undefined,
                        imageAlt: detail.imageAlt,
                      })}
                      locale={locale}
                      messages={installMessages}
                      className="mt-6 mb-4 max-w-none max-nav:mt-5 max-nav:mb-6"
                    />
                  ) : loading ? (
                    <span
                      className="mt-6 mb-2 block h-11 w-full max-w-[16rem] animate-pulse rounded-full bg-ink/[0.07]"
                      aria-hidden
                    />
                  ) : null}
                </div>
              </>
            ) : null}
          </div>
        </div>
      </div>

      {hasFlight && imageUrl ? (
        <div
          ref={flyRef}
          className={cn(
            "pointer-events-none fixed z-[90] overflow-hidden bg-[#ebe7df]",
            phase === "to" &&
              "transition-[top,left,width,height,border-radius] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
          )}
          style={flyStyle}
        >
          <PreviewCoverImage
            src={imageUrl}
            alt=""
            blurDataURL={articleActive.origin.blurDataURL}
            sizes="50vw"
            priority
          />
        </div>
      ) : null}
    </div>
  );
}
